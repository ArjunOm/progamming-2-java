package com.example.lab01arjunvaswani;

import java.util.Scanner;

public class StudentApp {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Student student = null;

        // Student Management
        while (true) {
            System.out.println("\nStudent Management System");
            System.out.println("1. Add New Student");
            System.out.println("2. View Student");
            System.out.println("3. Update Student's Grade");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int option = keyboard.nextInt();
            keyboard.nextLine();

            //logic
            switch (option) {
                case 1:
                    System.out.print("Enter student name: ");
                    String name = keyboard.nextLine();

                    System.out.print("Enter student ID: ");
                    int id = 0;
                    while (true) {
                        try {
                            id = Integer.parseInt(keyboard.nextLine());
                            break;
                        } catch (NumberFormatException e) {
                            System.out.print("Invalid ID. Please enter a valid integer ID: ");
                        }
                    }

                    System.out.print("Enter student grade: ");
                    double grade = 0.0;
                    while (true) {
                        try {
                            grade = Double.parseDouble(keyboard.nextLine());
                            break;
                        } catch (NumberFormatException e) {
                            System.out.print("Invalid grade. Please enter a valid grade: ");
                        }
                    }

                    student = new Student(name, id, grade);
                    System.out.println("Student added successfully.");
                    break;

                case 2:
                    if (student == null) {
                        System.out.println("No student record found.");
                    } else {
                        student.displayStudent();
                    }
                    break;

                case 3:
                    if (student == null) {
                        System.out.println("No student record found.");
                    } else {
                        System.out.print("Enter new grade: ");
                        double newGrade = 0.0;
                        while (true) {
                            try {
                                newGrade = Double.parseDouble(keyboard.nextLine());
                                break;
                            } catch (NumberFormatException e) {
                                System.out.print("Invalid grade. Please enter a valid grade: ");
                            }
                        }

                        student.setGrade(newGrade);
                        System.out.println("Grade updated successfully.");
                    }
                    break;

                case 4:
                    System.out.println("Exiting the program...");
                    keyboard.close();
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}